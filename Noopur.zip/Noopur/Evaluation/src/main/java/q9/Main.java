package q9;

import java.util.Objects;

class Emp{
	String name;
	double salary;
	
	public Emp(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, salary);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Emp other = (Emp) obj;
		return Objects.equals(name, other.name)
				&& Double.doubleToLongBits(salary) == Double.doubleToLongBits(other.salary);
	}
}

public class Main {
	public static void main(String[] args) {
		
		Emp ob = new Emp("harry", 798880);
		System.out.println(ob.name);
		System.out.println(ob.salary);
	}
}
