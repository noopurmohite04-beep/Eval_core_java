package q12;

class Emp {
	String name;
	int id;
	double salary;
	public Emp(String name, int id, double salary) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;
	}
	
	public void display() {
		System.out.println(name);
		System.out.println(id);
		System.out.println(salary);

	}
}

public class Main {
	public static void main(String[] args) {
		
		Emp emp = new Emp("tom", 11, 66680);
		emp.display();
	}
}
