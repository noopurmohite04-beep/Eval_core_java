package q18;

class Var{
	int a = 10;
	static int b = 20;
	
	public void show() {
		int c = 30;
		System.out.println(c);
		System.out.println(a);
		System.out.println(b);

	}
	
}
public class Main {
	public static void main(String[] args) {
		
		Var ob = new Var();
		ob.show();
	}
}
