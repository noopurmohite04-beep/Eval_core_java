package q13;

class Hobby{
	String h1;
	String h2;
}

class Address{
	String area;
	String location;
}

class Person{
	String name;
	Hobby hobby;
	Address address;
}


public class Main {
	public static void main(String[] args) {
//		Person ob = new Person("tom", Hobby, Address);
//		Hobby hob = new Hobby("dance", "read");
//		Address ad = new Address("mumbai", "borivali");
//		System.out.println(ob.name);
//		System.out.println(ob.hobby);
//		System.out.println(ob.address);
		System.out.println();
	}
}
