package q2;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class Main {
public static void main(String[] args) {
	Properties properties=new Properties();
	properties.put("Jack", "11");
	properties.put("harryy", "12");
	properties.put("tom", "13");
	
	Set set=properties.keySet();
	Iterator iterator=set.iterator();
	while (iterator.hasNext()) {
		String object = (String) iterator.next();
		System.out.println(properties.getProperty("tom", "not found"));
		
	}
}
}
