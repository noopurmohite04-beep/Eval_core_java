package q19;

class School{
	
	void outermeth() {
		final int data = 1300;
	
		class Student{
			void innermeth() {
				System.out.println(data);
			}
		}
		Student st= new Student();
		st.innermeth();
	}
}
public class Main {
	public static void main(String[] args) {
		School sc= new School();
		sc.outermeth();
	}
}
