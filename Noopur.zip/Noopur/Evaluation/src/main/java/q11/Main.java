package q11;

import java.util.Objects;
class Emp implements Cloneable{
	String name;
	int id;
	double sal;
	
	public Emp(String name, int id, double sal) {
		super();
		this.name = name;
		this.id = id;
		this.sal = sal;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, sal);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Emp other = (Emp) obj;
		return id == other.id && Objects.equals(name, other.name)
				&& Double.doubleToLongBits(sal) == Double.doubleToLongBits(other.sal);
	}

	@Override
	public String toString() {
		return "Emp [name=" + name + ", id=" + id + ", sal=" + sal + "]";
	}
	@Override
	protected void finalize() throws Throwable {
		System.out.println("ob deleted..");
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}

public class Main {
	public static void main(String[] args) throws CloneNotSupportedException {
		Emp ob = new Emp("tom", 10000, 10);

		ob=null;
		System.gc();
		
		Emp ob2 = new Emp("tomi", 20000, 20);
		Emp ob3 = new Emp("tomy", 30000, 30);
		System.out.println("Original : " + ob2);
		System.out.println(ob2.equals(ob3));
		
		Emp empclone= (Emp) ob3.clone();
		System.out.println("Cloned : " + empclone);
		
	}
}


