package q1com.hospital.staff.doctor.salary;

public class Salary {
	public double salary = 100000;
}
