package q1com.hospital.staff.doctor.salary;

public class DirectAccess extends q1com.hospital.staff.doctor.salary.Salary {
	public static void main(String[] args) {
		Salary ob = new Salary();
		System.out.println(ob.salary);
		
	}
}
