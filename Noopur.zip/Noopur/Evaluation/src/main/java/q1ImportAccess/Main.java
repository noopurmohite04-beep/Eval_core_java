package q1ImportAccess;

import q1com.hospital.staff.doctor.salary.*;

public class Main {
	public static void main(String[] args) {
		Salary ob = new Salary();
		System.out.println(ob.salary);
	}
}
