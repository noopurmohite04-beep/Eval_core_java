package q4operation;
import java.util.List;

import q4pojo.EmpPojo;

public interface Operation {
	void add(List<EmpPojo> l);
	void update(int id,String name);
	void delete(int id);
	void search(int id);
	void show();
}

