package q17;

class Company{
	public void cname() {
		System.out.println("Parent class");
	}
}

class Manager extends Company{
	@Override
	public void cname() {
		System.out.println("multilevel 1");
	}
}

class Emp extends Company{
	@Override
	public void cname() {
		System.out.println("multilevel 2");
	}
	
	public void new_m() {
		System.out.println("hierarchy parent");

	}
}

class Intern extends Emp{
	@Override
	public void new_m() {
		System.out.println("heirarchy level");
	}
}
public class Main {
	public static void main(String[] args) {
		Company c = new Company();
		c.cname();
		
		Manager m = new Manager();
		m.cname();
		
		Emp e = new Emp();
		e.cname();
		e.new_m();
		
		Intern i = new Intern();
		i.new_m();
	}
}
