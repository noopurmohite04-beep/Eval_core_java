package q5;


class School{
	static int data = 1000;
	static class Student {
		static void studmeth() {
			System.out.println(data);
		}
	}
}

public class Main {
	public static void main(String[] args) {
		School.Student inner = new School.Student();
		q5.School.Student.studmeth();
	}
}
