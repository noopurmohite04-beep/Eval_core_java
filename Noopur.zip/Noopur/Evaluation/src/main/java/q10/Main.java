package q10;

class Bank{
	public void calsal(double sal) {
		System.out.println(sal);
	}
	public void calsal(double sal, double bonus) {
		System.out.println(sal + bonus);

	}
	
}

class CA extends Bank{
	@Override
	public void calsal(double sal) {
		System.out.println(sal);
	}
	@Override
	public void calsal(double sal, double bonus) {
		System.out.println(sal + bonus);
	}
}
public class Main {
	public static void main(String[] args) {
		CA ob = new CA();
		ob.calsal(200000);
		ob.calsal(200000, 6000);
	}
}








