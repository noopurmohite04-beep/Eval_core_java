package q14;

public class Main {
	public static void main(String[] args) {
		
		try {
		int val[] = new int[10];
		val[10]=10/0;
		
		}catch (ArithmeticException e) {
			System.out.println("arithmetic error");
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("index exceed error");
		}
	}
}

