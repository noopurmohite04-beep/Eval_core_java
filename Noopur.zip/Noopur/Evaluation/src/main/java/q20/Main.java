package q20;

class Stud{
	void meth1() {}
}
class Emp{
	void meth2() {}
}
class Man{
	void meth3(Stud a, Emp b) {
		a.meth1();
		b.meth2();	
	}
}
public class Main {
	public static void main(String[] args) {
		Man c =new Man();
		c.meth3(new Stud(){
			@Override
			void meth1() {
				System.out.println("tom");
			}
		}, 
		new Emp() {
			@Override
			void meth2() {
				System.out.println("harry");
			}
		});
		
	}
}



